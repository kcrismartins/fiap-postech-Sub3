export interface UpdateProductPresenter {
  productWasUpdated: boolean;
}
