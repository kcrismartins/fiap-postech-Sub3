export interface CreateProductCategoryPresenter {
  categoryId: string;
}
