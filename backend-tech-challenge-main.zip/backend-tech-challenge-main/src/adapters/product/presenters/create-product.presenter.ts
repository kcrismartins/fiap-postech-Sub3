export interface CreateProductPresenter {
  productId: string;
}
