  export enum OrderStatus {
    WAITING_PAYMENT = 1,
    PAYMENT_APPROVED = 2,
    PREPARING_ORDER = 3,
    ORDER_DONE = 4

  }

